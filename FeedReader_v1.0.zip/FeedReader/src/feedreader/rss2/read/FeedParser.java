package feedreader.rss2.read;

import java.io.InputStream;
import java.net.URL;

import feedreader.rss2.model.Feed;

public interface FeedParser {

	public InputStream openFeed(URL url);
	public Feed readFeed(URL url);
	public String applyConversion(String value);
	
}
