package feedreader.rss2.read;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.XMLEvent;

import feedreader.rss2.model.Feed;
import feedreader.rss2.model.FeedMessage;

public class RSS2FeedParser implements FeedParser {
	private static final String ITEM = "item";
	private Set<String> feedFieldsSet = new HashSet<String>();
	private Set<String> filterStringsSet = new HashSet<String>();

	public void setFeedFieldsSet(Set<String> feedFieldsSet) {
		this.feedFieldsSet = feedFieldsSet;
	}	

	public void setFilterStringsSet(Set<String> filterStringsSet) {
		this.filterStringsSet = filterStringsSet;
	}

	public RSS2FeedParser() {

	}
	
	@Override
	public Feed readFeed(URL url) {
		Feed feed = null;
		Map<String, String> fieldsMap = new LinkedHashMap<String, String>();
		//Map<String, String> feedMessagefieldsMap = new LinkedHashMap<String, String>();
		
		boolean feedFieldsCollected = true;
		XMLInputFactory inputFactory = null;
		
		InputStream in = null;
		XMLEventReader eventReader = null;
		
		String localPart = null;

		try {
			// First create a new XMLInputFactory
			inputFactory = XMLInputFactory.newInstance();
			inputFactory.setProperty(XMLInputFactory.IS_COALESCING, true);

			// Setup a new eventReader
			in = openFeed(url);
			eventReader = inputFactory.createXMLEventReader(in);

			// Read the XML document
			while (eventReader.hasNext()) {
				XMLEvent event = eventReader.nextEvent();

				if (event.isStartElement()) {
					localPart = event.asStartElement().getName()
							.getLocalPart();

					if (localPart.equals(ITEM)) {
						if (feedFieldsCollected) {
							feedFieldsCollected = false;
							feed = new Feed();
							feed.setFieldsMap(fieldsMap);
						}
						fieldsMap = new LinkedHashMap<String, String>();
						event = eventReader.nextEvent();
					} else {
						if( feedFieldsSet.contains(localPart) ){
							fieldsMap.put(localPart, applyConversion(getCharacterData(event, eventReader)) );	
						}
					}

				} else if (event.isEndElement()) {
					localPart = event.asEndElement().getName()
							.getLocalPart();
					
					if (localPart.equals(ITEM)) {
						FeedMessage message = new FeedMessage();
						message.setFieldsMap(fieldsMap);
						feed.getMessages().add(message);
						fieldsMap = new LinkedHashMap<String, String>();
						event = eventReader.nextEvent();
						continue;
					}
				}
			}
		} catch (XMLStreamException e) {
			throw new RuntimeException(e);
		}
		return feed;
	}
	
	@Override
	public String applyConversion(String originalValue){//Remove filter Strings from supplied field value
		String convertedValue;
		
		if(originalValue == null || originalValue.equals("")){
			return "";
		} else {
			convertedValue = originalValue;
			for (String filterString : filterStringsSet) {
				convertedValue = convertedValue.replace(filterString, "");
			}			
		}
		return convertedValue;
	}

	private String getCharacterData(XMLEvent event, XMLEventReader eventReader)
			throws XMLStreamException {

		String result = "";
		event = eventReader.nextEvent();

		if (event instanceof Characters) {
			result = event.asCharacters().getData();
		}
		return result;
	}

	@Override
	public InputStream openFeed(URL url) {
		try {
			return url.openStream();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}