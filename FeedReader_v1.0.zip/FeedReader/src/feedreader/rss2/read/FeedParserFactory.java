package feedreader.rss2.read;

public class FeedParserFactory {
 
	   public FeedParser getFeedParser(String feedParserType){
		   
	      if(feedParserType == null){
	         return null;
	      }		
	      if(feedParserType.equalsIgnoreCase("RSS2")){
	         return new RSS2FeedParser();
	         
	      } else if(feedParserType.equalsIgnoreCase("TWITTER")){
	         //return new TwitterFeedParser();//TODO - If there's a need to implement Twitter Feed
	         
	      }
	      return null;
	   }
}
