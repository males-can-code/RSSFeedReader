package feedreader.rss2.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

/*
 * Stores an RSS2 feed
 */
public class Feed {

	final List<FeedMessage> entries = new ArrayList<FeedMessage>();
	Map<String, String> fieldsMap = new LinkedHashMap<String, String>();

	public List<FeedMessage> getMessages() {
		return entries;
	}

	public Map<String, String> getFieldsMap() {
		return fieldsMap;
	}

	public void setFieldsMap(Map<String, String> fieldsMap) {
		this.fieldsMap = fieldsMap;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("[");

		Set<Map.Entry<String, String>> entrySet = fieldsMap.entrySet();

		for (Entry<String, String> entry : entrySet) {
			if (entry.getValue() != null && !(entry.getValue().equals(""))) {
				sb.append(entry.getKey()).append(": ")
				.append(entry.getValue()).append(", ");
			}
		}
		sb.delete(sb.length() - 2, sb.length());
		sb.append("]\n");
		return sb.toString();
	}	
	
	public String getFieldFromFeed(String field) {
		
		if( fieldsMap.containsKey(field) ){
			return fieldsMap.get(field);
		} else {
			return "";
		}
	}//getFieldFromFeed
}