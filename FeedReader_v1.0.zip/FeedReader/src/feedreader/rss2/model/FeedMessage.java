package feedreader.rss2.model;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/*
 * Represents one RSS entry.getValue()
 */
public class FeedMessage {

	Map<String, String> fieldsMap = new LinkedHashMap<String, String>();

	public Map<String, String> getFieldsMap() {
		return fieldsMap;
	}

	public void setFieldsMap(Map<String, String> fieldsMap) {
		this.fieldsMap = fieldsMap;
	}

	@Override
	public String toString() {
		int indexOfFirstNewLineChar = 0; 
		StringBuilder sb = new StringBuilder();

		Set<Map.Entry<String, String>> entrySet = fieldsMap.entrySet();

		for (Entry<String, String> entry : entrySet) {
			if (entry.getValue() != null && !(entry.getValue().equals(""))) {

				if (entry.getValue().length() > 50) {
					if( entry.getValue().contains("\n")){
						indexOfFirstNewLineChar = entry.getValue().indexOf("\n");
						
						sb.append(entry.getKey()).append(": ")
						.append(entry.getValue().substring(0, Math.min(50, indexOfFirstNewLineChar)))
						.append("...").append("\n");						
					}

				} else {
					sb.append(entry.getKey()).append(": ")
							.append(entry.getValue()).append("\n");
				}
			}
		}
		return sb.toString();
	}
}