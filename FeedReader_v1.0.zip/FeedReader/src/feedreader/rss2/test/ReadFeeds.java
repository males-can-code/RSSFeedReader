package feedreader.rss2.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import feedreader.rss2.model.Feed;
import feedreader.rss2.model.FeedMessage;
import feedreader.rss2.read.FeedParserFactory;
import feedreader.rss2.read.RSS2FeedParser;

public class ReadFeeds {

	private static Set<String> feedFieldsSet = new HashSet<String>();
	private static Set<String> filterStringsSet = new HashSet<String>();

	private static String feedOutputFolderPath;
	private static int maxContentLengthForConsole;

	public static void main(String[] args) {

		URL url = null;
		Feed feed = null;
		RSS2FeedParser rss2FeedParser = null;
		
		try {
			readPropertiesAndPopulateFields();
			FeedParserFactory feedParserFactory = new FeedParserFactory();
			
			//Loop through all URLs supplied as program arguments (exception will be thrown if URL is malformed)
			for(String feedUrl: args){
				
				System.out.println("Reading feed from: " + feedUrl + "...");
				url = new URL(feedUrl);
				
				rss2FeedParser = (RSS2FeedParser) feedParserFactory.getFeedParser("RSS2");
				rss2FeedParser.setFeedFieldsSet(feedFieldsSet);
				rss2FeedParser.setFilterStringsSet(filterStringsSet);
				
				feed = rss2FeedParser.readFeed(url);
				parseFeed(feed, feedUrl);//Parses feed and displays content on console as well saves to file.
				System.out.println("########################## Done reading feed from: " + feedUrl + " ##########################\n");
			}

		} catch (Exception Ex) {
			System.err
					.println("A System Error occured while handling one or more RSS feeds. Description of the error is as below: \n");
			Ex.printStackTrace();

		} finally {
			rss2FeedParser = null;
			
		}
		
	}//main

	//Parses feed and displays content on console as well saves to file.
	public static void parseFeed(Feed feed, String feedUrl) {

		String message;
		Map<String, String> feedMessageFieldsMap = null;
		 
		StringBuilder feedContentForConsole = new StringBuilder();		
		StringBuilder feedContentForFile = new StringBuilder();
		
		String feedTitle, feedDetails = "";
		
		int collapseCounter = 0;
		
		try {
			
			feedTitle = feed.getFieldFromFeed("title");
			if(feedTitle == null || feedTitle.equals("")){
				feedTitle = feedUrl;
			}
			feedDetails = getFormattedRSSFeedDetails(feed.getFieldsMap());

			//Collect content for display on console and saving in file
			for (FeedMessage feedMessage : feed.getMessages()) {
				feedMessageFieldsMap = feedMessage.getFieldsMap();

				feedContentForConsole.append("\n");
				feedContentForFile.append("\n");
				
				for (Entry<String, String> entry : feedMessageFieldsMap.entrySet()) {
					
					if (entry.getValue() != null && !(entry.getValue().equals("")) ) {
						
						if(entry.getValue().length() <= maxContentLengthForConsole){
							//Populate feedContentForConsole
							feedContentForConsole.append(entry.getKey()).append(": ")
							.append(entry.getValue()).append("\n");
							
							//Populate feedContentForFile
							if(entry.getKey().equals("link")){
								feedContentForFile.append("<a href=\"")
										.append(entry.getValue()).append("\">")
										.append(entry.getValue()).append("</a>")
										.append("<br>");
								
							} else if(entry.getKey().equals("title")){
								feedContentForFile.append("<b>").append(entry.getValue()).append("</b>").append("<br>");
																
							} else if(entry.getKey().equals("pubDate")){
								feedContentForFile.append("(Published").append(": ").append(entry.getValue()).append(")").append("<br>");
																
							} else if(entry.getKey().equals("guid")){
								//Do Nothing
								
							} else {
								feedContentForFile.append(entry.getKey()).append(": ").append(entry.getValue()).append("<br>");
							}
							
						} else {
							//Populate feedContentForConsole							
							feedContentForConsole.append(entry.getKey()).append(": ")
							.append(entry.getValue().substring(0, maxContentLengthForConsole)).append("(Large content, please refer to generated file.)").append("\n");
							
							//Populate feedContentForFile
							++collapseCounter;
							
							feedContentForFile
								.append("<a data-toggle=\"collapse\" href=\"#collapse").append(collapseCounter).append("\">View / Hide '").append(entry.getKey()).append("'</a>")
								.append("<br>")
								.append("<div id=\"collapse").append(collapseCounter).append("\" class=\"panel-collapse collapse\">")
								.append("<div class=\"panel-body\">")
								.append(entry.getValue())
								.append("</div>")
								.append("</div>");					
						}
					}
				}
				feedContentForConsole.append("\n");
				feedContentForFile.append("<br>");
				
			}
			
			//Display Content on console
			System.out.println(feedContentForConsole.toString());
			
			//Write feed content to file
			writeFeedToFile(feedContentForFile.toString(), feedTitle, feedDetails);
			
		}catch(Exception Ex){
			throw new RuntimeException(Ex);
			
		} finally{
			feed = null;
		}

	}//parseFeed
	
	private static String getCurrentTimeStamp(String format) {
		SimpleDateFormat sdfDate = new SimpleDateFormat(format);// dd/MM/yyyy //"yyyy-MM-dd HH:mm:ss"
		Date now = new Date();
		String strDate = sdfDate.format(now);
		return strDate;
	}//getCurrentTimeStamp

	public static void readPropertiesAndPopulateFields() {

		Properties prop = new Properties();
		InputStream input = null;

		String feedFields;
		String filterStrings;
		String maxContentLengthForConsoleStr;
		
		try {
			input = new FileInputStream("config/config.properties");

			//Load properties file
			prop.load(input);

			//Get the property value and store it in global variables as appropriate
			feedFields = prop.getProperty("feedFields");
			filterStrings = prop.getProperty("filterStrings");
			feedOutputFolderPath = prop.getProperty("feedOutputFolderPath");
			maxContentLengthForConsoleStr = prop.getProperty("maxContentLengthForConsole");
			
			if( maxContentLengthForConsoleStr != null && !maxContentLengthForConsoleStr.equals("") ){
				maxContentLengthForConsole = Integer.parseInt(maxContentLengthForConsoleStr);
			}
			
			for (String str : feedFields.split(",")) {
				feedFieldsSet.add(str);
			}
			
			for (String str : filterStrings.split(",")) {
				filterStringsSet.add(str);
			}
			
		} catch (IOException ex) {
			throw new RuntimeException(ex);
			
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}//readPropertiesAndPopulateFields

	public static void writeFeedToFile(String content, String feedTitle, String feedDetails) {
		
		StringBuilder htmlContentForFile = new StringBuilder();
		StringBuilder outputFileName = new StringBuilder();
		
		try {
			htmlContentForFile.append("\\<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
			htmlContentForFile.append("<html>").append("\n");
			htmlContentForFile.append("<head>").append("\n");
			htmlContentForFile.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">").append("\n");			
			htmlContentForFile.append("<link rel=\"stylesheet\" href=\"http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\">").append("\n");
			htmlContentForFile.append("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>").append("\n");
			htmlContentForFile.append("<script src=\"http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js\"></script>").append("\n");
			htmlContentForFile.append("<title>FeedReader</title>").append("\n");
			htmlContentForFile.append("<style>").append("\n");
			htmlContentForFile.append("h1 {color:SteelBlue;font-family:verdana;font-size:19px;font-weight:bold;margin-top:40px;margin-bottom:5px;margin-left:40px;}").append("\n");
			htmlContentForFile.append("h2 {color:Black;font-family:Helvetica;font-size:12.5px;font-weight:normal;margin-top:5px;margin-bottom:5px;margin-left:40px;}").append("\n");
			htmlContentForFile.append("div {color:black;font-family:Helvetica;font-size:13.5px;margin-top:15px;margin-bottom:5px;margin-left:40px;}").append("\n");
			htmlContentForFile.append("a {color:#4682B4;}").append("\n");
			htmlContentForFile.append("</style>").append("\n");
			htmlContentForFile.append("</head>").append("\n");
			htmlContentForFile.append("<body>").append("\n");
			htmlContentForFile.append("<h1>").append(feedTitle).append("</h1>").append("\n");
			htmlContentForFile.append("<h2>").append(feedDetails).append("</h2>").append("\n");
			htmlContentForFile.append("<hr>").append("\n");
			htmlContentForFile.append("<div>").append("\n");
			
			htmlContentForFile.append(content).append("\n");
			
			htmlContentForFile.append("</div>").append("\n");
			htmlContentForFile.append("</body>").append("\n");
			htmlContentForFile.append("</html>");
			
			outputFileName.append(feedOutputFolderPath).append(feedTitle.trim()).append(getCurrentTimeStamp("_yyyy-MM-dd_HHmmss-SSS")).append(".html");
			File file = new File(outputFileName.toString());

			// if file doesn't exists then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(htmlContentForFile.toString());
			bw.close();

			System.out.println("Created file: " + outputFileName.toString() + " with feed content.");

		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}// writeFeedToFile
	
	private static String getFormattedRSSFeedDetails(Map<String, String> fieldsMap) {
		StringBuilder sb = new StringBuilder();

		sb.append("[");

		Set<Map.Entry<String, String>> entrySet = fieldsMap.entrySet();

		for (Entry<String, String> entry : entrySet) {
			if( !(entry.getKey().equals("title")) ){
				if (entry.getValue() != null && !(entry.getValue().equals(""))) {
					
					if(entry.getKey().equals("link") || entry.getKey().equals("docs")){
						sb.append("<b>").append(entry.getKey()).append(": ").append("</b>").append("<a href=\"")
								.append(entry.getValue()).append("\">")
								.append(entry.getValue()).append("</a>")
								.append(", ");
						
					} else {
						sb.append("<b>").append(entry.getKey()).append(": ").append("</b>")
						.append(entry.getValue()).append(", ");						
					}
				}
			}
		}
		sb.delete(sb.length() - 2, sb.length());
		sb.append("]\n");
		return sb.toString();
	}	

}