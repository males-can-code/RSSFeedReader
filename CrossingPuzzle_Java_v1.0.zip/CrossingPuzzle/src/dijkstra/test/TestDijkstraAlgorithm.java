package dijkstra.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import dijkstra.engine.DijkstraAlgorithm;
import dijkstra.model.Edge;
import dijkstra.model.Graph;
import dijkstra.model.Vertex;

public class TestDijkstraAlgorithm {

	private List<Vertex> nodes;
	private List<Edge> edges;

	@Test
	public void testExcute() {
		nodes = new ArrayList<Vertex>();
		edges = new ArrayList<Edge>();
		
		Vertex location = new Vertex("Node_A", "Node_A");
		nodes.add(location);
		location = new Vertex("Node_B", "Node_B");
		nodes.add(location);
		location = new Vertex("Node_C", "Node_C");
		nodes.add(location);
		location = new Vertex("Node_D", "Node_D");
		nodes.add(location);
		location = new Vertex("Node_E", "Node_E");
		nodes.add(location);
		location = new Vertex("Node_F", "Node_F");
		nodes.add(location);
		location = new Vertex("Node_G", "Node_G");
		nodes.add(location);
		location = new Vertex("Node_H", "Node_H");
		nodes.add(location);
		location = new Vertex("Node_I", "Node_I");
		nodes.add(location);
		location = new Vertex("Node_J", "Node_J");
		nodes.add(location);
		location = new Vertex("Node_K", "Node_K");
		nodes.add(location);
		location = new Vertex("Node_L", "Node_L");
		nodes.add(location);
		location = new Vertex("Node_M", "Node_M");
		nodes.add(location);
		
		location = new Vertex("Node_N", "Node_N");
		nodes.add(location);	
		
		/*
		addLane("Edge_0", 0, 2, 20 + epsilon);
		addLane("Edge_1", 2, 3, 30 + epsilon);
		addLane("Edge_2", 3, 4, 20 + epsilon);
		addLane("Edge_3", 3, 7, 10 + epsilon);
		addLane("Edge_4", 7, 8, 35 + epsilon);
		addLane("Edge_5", 4, 8, 15 + epsilon);
		addLane("Edge_6", 8, 11, 20 + epsilon);
		addLane("Edge_7", 11, 12, 45 + epsilon);
		addLane("Edge_8", 12, 1, 10 + epsilon);
		addLane("Edge_9", 4, 5, 40 + epsilon);
		addLane("Edge_10", 5, 9, 31 + epsilon);
		addLane("Edge_11", 9, 10, 22 + epsilon);
		addLane("Edge_12", 10, 6, 30 + epsilon);
		addLane("Edge_13", 5, 6, 15 + epsilon);
		addLane("Edge_14", 6, 1, 35 + epsilon);
		addLane("Edge_15", 0, 9, 33 + epsilon);
		addLane("Edge_16", 8, 12, 50 + epsilon);
		addLane("Edge_17", 0, 4, 30 + epsilon);
		
		addLane("Edge_18", 0, 13, 40 + epsilon);
		addLane("Edge_19", 13, 1, 45 + epsilon);
		
		addLane("Edge_20", 0, 1, 100 + epsilon);
		*/		

		addLane("Edge_0", 0, 2, 1);
		addLane("Edge_1", 2, 3, 1);
		addLane("Edge_2", 3, 4, 1);
		addLane("Edge_3", 3, 7, 1);
		addLane("Edge_4", 7, 8, 1);
		addLane("Edge_5", 4, 8, 1);
		addLane("Edge_6", 8, 11, 1);
		addLane("Edge_7", 11, 12, 1);
		addLane("Edge_8", 12, 1, 1);
		addLane("Edge_9", 4, 5, 1);
		addLane("Edge_10", 5, 9, 1);
		addLane("Edge_11", 9, 10, 1);
		addLane("Edge_12", 10, 6, 1);
		addLane("Edge_13", 5, 6, 1);
		addLane("Edge_14", 6, 1, 1);
		addLane("Edge_15", 0, 9, 1);
		addLane("Edge_16", 8, 12, 1);
		addLane("Edge_17", 0, 4, 1);
		
		//addLane("Edge_18", 0, 13, 1);
		//addLane("Edge_19", 13, 5, 1);

		// Lets check from location Loc_1 to Loc_10
		Graph graph = new Graph(nodes, edges);
		DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
		dijkstra.execute(nodes.get(0));
		LinkedList<Vertex> path = dijkstra.getPath(nodes.get(1));

		assertNotNull(path);
		assertTrue(path.size() > 0);

		StringBuilder outputPath = new StringBuilder(); 
		for (Vertex vertex : path) {
			outputPath.append(vertex).append(" > ");
		}
		outputPath.delete(outputPath.length()-3, outputPath.length());
		System.out.println(outputPath);

	}

	private void addLane(String laneId, int sourceLocNo, int destLocNo,
			int duration) {
		Edge lane = new Edge(laneId, nodes.get(sourceLocNo),
				nodes.get(destLocNo), duration);
		edges.add(lane);
	}
}
